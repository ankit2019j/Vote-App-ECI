package ankit.com.vote_app_chandni_chowk;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class knowyourconstituency extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_knowyourconstituency);
    }
}
