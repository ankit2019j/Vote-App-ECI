package ankit.com.vote_app_chandni_chowk;

import com.google.android.gms.maps.GoogleMap;

public interface OnMapReadyCallback {
    void onMapReady(GoogleMap var1);

}
